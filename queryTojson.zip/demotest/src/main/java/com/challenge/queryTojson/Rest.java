/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.challenge.queryTojson;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.regex.Pattern;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author abhinay
 */
@Path("json")
public class Rest {

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response json(String querystring) throws Exception {

        String query = querystring;
        if(query==null || query.equals("")){
             ObjectMapper mapper = new ObjectMapper();
                return Response.status(400).entity(mapper.writeValueAsString("please provide valid query")).type(MediaType.APPLICATION_JSON).build();

        }
        String idstr = null, namestr = null, fn = null, mn = null, ln = null, datestr = null, locationarrstr = null, locname = null, lng = null, lat = null, imageidstr = null;
        JSONObject jsonobj = new JSONObject();
        JSONObject nameobj = new JSONObject();
        JSONObject cordsobj = new JSONObject();
        JSONObject locationobj = new JSONObject();

        String[] stringarray = query.split(Pattern.quote("|"));
        System.out.println("length=" + stringarray.length + "last char is " + query.substring(query.length() - 1));

        if (stringarray.length >= 5) {

            idstr = stringarray[1];
            namestr = stringarray[2];
            datestr = stringarray[3];
            locationarrstr = stringarray[4];

        }

        for (int i = 0; i < stringarray.length; i++) {
            System.out.println(stringarray[i]);
        }
        JSONArray jsonlocationarray = new JSONArray();
        if (query.substring(query.length() - 1).equals("|")) {
            if (stringarray.length < 5) {

                System.out.println("invalid query");
                   ObjectMapper mapper = new ObjectMapper();
                return Response.status(400).entity(mapper.writeValueAsString("invalid query")).type(MediaType.APPLICATION_JSON).build();

            }
            imageidstr = "";

        } else if (stringarray.length < 6) {
            System.out.println("invalid query");   ObjectMapper mapper = new ObjectMapper();
            return Response.status(400).entity(mapper.writeValueAsString("invalid query")).type(MediaType.APPLICATION_JSON).build();
        }
        imageidstr = stringarray[5];

        jsonobj.put("id", idstr);
        String[] namearray = namestr.split(Pattern.quote("><"));
        fn = namearray[0];
        mn = namearray[1];
        ln = namearray[2];
        fn = fn.replace("<", "");
        ln = ln.replace(">", "");
        nameobj.put("first", fn);
        nameobj.put("middle", mn);
        nameobj.put("last", ln);
        jsonobj.put("name", nameobj);
        String[] locationarray = locationarrstr.split(Pattern.quote(","));
        for (int j = 0; j < locationarray.length; j++) {
            String[] locarr = locationarray[j].split(Pattern.quote("><"));
            locname = locarr[0];
            lng = locarr[1];
            lat = locarr[2];
            locname = locname.replace("[", "");
            locname = locname.replace("<", "");
            lng = lng.replace("<", "");
            lat = lat.replace(">>", "");

            cordsobj.put("long", lng);
            cordsobj.put("lat", lat);

            locationobj.put("name", locname);
            locationobj.put("coords", cordsobj);

            jsonlocationarray.add(locationobj);

        }

        jsonobj.put("Location", jsonlocationarray);

        jsonobj.put("imageId", imageidstr);

        ObjectMapper mapper = new ObjectMapper();

        return Response.status(200).entity(mapper.writeValueAsString(jsonobj)).type(MediaType.APPLICATION_JSON).build();
    }

}
